import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import type { ReactNode } from "react";
import { PageTransition } from "@/components/navigation/page-transition";
import { getUserAppTheme } from "@/lib/app-theme-store";
import "./globals.css";

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["500", "700"],
  variable: "--font-mono",
});

export const metadata: Metadata = {
  metadataBase: "https://blindspots.gg",
  title: {
    default: "Blindspots.gg - Chess Training for the Positions You Keep Getting Wrong",
    template: "%s | Blindspots.gg",
  },
  description:
    "Blindspots.gg is position-based chess training that finds recurring chess mistakes and recommends similar positions you are likely to struggle with.",
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Blindspots.gg - Chess Training for the Positions You Keep Getting Wrong",
    description:
      "Position-based chess training that finds recurring mistakes and recommends similar positions you are likely to struggle with.",
    url: "https://blindspots.gg",
    siteName: "Blindspots.gg",
    type: "website",
    images: ["/og.png"],
  },
  twitter: {
    card: "summary_large_image",
    title: "Blindspots.gg - Chess Training for the Positions You Keep Getting Wrong",
    description:
      "Position-based chess training that finds recurring mistakes and recommends similar positions you are likely to struggle with.",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  const theme = await getUserAppTheme();

  return (
    <html
      lang="en"
      className={jetbrainsMono.variable}
      data-theme={theme ?? undefined}
    >
      <body>
        <PageTransition>{children}</PageTransition>
      </body>
    </html>
  );
}
